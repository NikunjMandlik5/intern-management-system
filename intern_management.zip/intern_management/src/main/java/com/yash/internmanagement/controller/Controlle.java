package com.yash.internmanagement.controller;

import com.yash.internmanagement.util.connection;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class Controlle extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Controlle() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirm_password = request.getParameter("confirm_password");
        String mobile = request.getParameter("mobile");
        String technology = request.getParameter("technology");
        String course = request.getParameter("course");
        String other_course = request.getParameter("other_course");
        String branch = request.getParameter("branch");
        String grad_completed = request.getParameter("grad_completed");
        String grad_year = request.getParameter("grad_year");
        String current_semester = request.getParameter("current_semester");
        String start_date = request.getParameter("start_date");
        String duration = request.getParameter("duration");
        String end_date = request.getParameter("end_date");
        String reference = request.getParameter("reference");

        try {
            Connection con = connection.getConnection();
            String insert_sql_query = "INSERT INTO register (name, email, password, mobile, technology, course, other_course, branch, grad_completed, grad_year, current_semester, start_date, duration, end_date, reference) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(insert_sql_query);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setString(4, mobile);
            ps.setString(5, technology);
            ps.setString(6, course);
            ps.setString(7, other_course);
            ps.setString(8, branch);
            ps.setString(9, grad_completed);
            ps.setString(10, grad_year);
            ps.setString(11, current_semester);
            ps.setString(12, start_date);
            ps.setString(13, duration);
            ps.setString(14, end_date);
            ps.setString(15, reference);

            int count = ps.executeUpdate();
            if (count > 0) {
              
                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                rd.forward(request, response);
            } else {
                out.println("<h3 style='color:red'>Registration Failed</h3>");
                RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
                rd.include(request, response);
            }

            ps.close();
            con.close();
        } catch (SQLException e) {
            out.println("<h3 style='color:red'>An error occurred: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        }
    }
}

