//package com.yash.TaskManagerSystem.controller;



//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import com.yash.TaskManagerSystem.domain.User;
//import com.yash.TaskManagerSystem.util.connection;
//
//@WebServlet("/admin")//login
//public class admin extends HttpServlet {
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        PrintWriter out = response.getWriter();
//        response.setContentType("text/html");
//
//        String email = request.getParameter("email");
//        String password = request.getParameter("password");
//
//        try {
//            // Check if admin credentials are used
//            if (email.equals("admin@1234.com") && password.equals("admin123")) {
//                // Admin login: Fetch all records
//                Connection con = connection.getConnection();
//                String query = "SELECT * FROM register";
//                PreparedStatement ps = con.prepareStatement(query);
//                ResultSet rs = ps.executeQuery();
//
//                // Create a list to hold all users
//                List<User> userList = new ArrayList<>();
//
//                // Iterate through the result set and create User objects
//                while (rs.next()) {
//                    User user = new User();
//                    user.setName(rs.getString("name"));
//                    user.setEmail(rs.getString("email"));
//                    user.setMobile(rs.getString("mobile"));
//                    user.setTechnology(rs.getString("technology"));
//                    user.setCourse(rs.getString("course"));
//                    user.setOther_course(rs.getString("other_course"));
//                    user.setBranch(rs.getString("branch"));
//                    user.setGrad_completed(rs.getString("grad_completed"));
//                    user.setGrad_year(rs.getString("grad_year"));
//                    user.setCurrent_semester(rs.getString("current_semester"));
//                    user.setStart_date(rs.getString("start_date"));
//                    user.setDuration(rs.getString("duration"));
//                    user.setEnd_date(rs.getString("end_date"));
//                    user.setReference(rs.getString("reference"));
//
//                    userList.add(user);
//                }
//
//                // Storing the list of users in session attribute
//                HttpSession session = request.getSession();
//                session.setAttribute("userList", userList);
//
//                // Closing resources
//                rs.close();
//                ps.close();
//                con.close();
//
//                // Forwarding to admin page to display all data
//                RequestDispatcher rd = request.getRequestDispatcher("/admin_dashboard.jsp");
//                rd.forward(request, response);
//
//            } else {
//                // Handling case where admin credentials are not correct
//                out.println("<h3 style='color:red'>Admin login failed: Incorrect credentials</h3>");
//                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
//                rd.include(request, response);
//            }
//
//        } catch (SQLException e) {
//            // Handle SQL exceptions
//            out.println("<h3 style='color:red'>Database error: " + e.getMessage() + "</h3>");
//            e.printStackTrace();
//        } catch (Exception e) {
//            // Handle other exceptions
//            out.println("<h3 style='color:red'>Error: " + e.getMessage() + "</h3>");
//            e.printStackTrace();
//        }
//    }
//}
//
//11
//package com.yash.TaskManagerSystem.controller;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import com.yash.TaskManagerSystem.domain.User;
//import com.yash.TaskManagerSystem.util.connection;
//
//@WebServlet("/admin")
//public class admin extends HttpServlet {
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        PrintWriter out = response.getWriter();
//        response.setContentType("text/html");
//
//        String email = request.getParameter("email");
//        String password = request.getParameter("password");
//
//        try {
//            // Check if admin credentials are used
//            if (email.equals("admin@1234.com") && password.equals("admin123")) {
//                // Admin login: Fetch all records
//                Connection con = connection.getConnection();
//                String query = "SELECT * FROM register";
//                PreparedStatement ps = con.prepareStatement(query);
//                ResultSet rs = ps.executeQuery();
//
//                // Create a list to hold all users
//                List<User> userList = new ArrayList<>();
//
//                // Iterate through the result set and create User objects
//                while (rs.next()) {
//                    User user = new User();
//                    user.setId(rs.getString("id"));
//                    user.setName(rs.getString("name"));
//                    user.setEmail(rs.getString("email"));
//                    user.setMobile(rs.getString("mobile"));
//                    user.setTechnology(rs.getString("technology"));
//                    user.setCourse(rs.getString("course"));
//                    user.setOther_course(rs.getString("other_course"));
//                    user.setBranch(rs.getString("branch"));
//                    user.setGrad_completed(rs.getString("grad_completed"));
//                    user.setGrad_year(rs.getString("grad_year"));
//                    user.setCurrent_semester(rs.getString("current_semester"));
//                    user.setStart_date(rs.getString("start_date"));
//                    user.setDuration(rs.getString("duration"));
//                    user.setEnd_date(rs.getString("end_date"));
//                    user.setReference(rs.getString("reference"));
//                    user.setStatesSelect(rs.getString("statesSelect"));
//                    userList.add(user);
//                }
//
//                // Storing the list of users in session attribute
//                HttpSession session = request.getSession();
//                session.setAttribute("userList", userList);
//
//                // Closing resources
//                rs.close();
//                ps.close();
//                con.close();
//
//                // Forwarding to admin page to display all data
//                RequestDispatcher rd = request.getRequestDispatcher("/admin_profile.jsp");
//                rd.forward(request, response);
//
//            } else {
//                // Handling case where admin credentials are not correct
//                out.println("<h3 style='color:red'>Admin login failed: Incorrect credentials</h3>");
//                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
//                rd.include(request, response);
//            }
//
//        } catch (SQLException e) {
//            // Handle SQL exceptions
//            out.println("<h3 style='color:red'>Database error: " + e.getMessage() + "</h3>");
//            e.printStackTrace();
//        } catch (Exception e) {
//            // Handle other exceptions
//            out.println("<h3 style='color:red'>Error: " + e.getMessage() + "</h3>");
//            e.printStackTrace();
//        }
//    }
//}
//
//
//
//
//
//11

//package com.yash.TaskManagerSystem.controller;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import com.yash.TaskManagerSystem.domain.User;
//import com.yash.TaskManagerSystem.util.connection;
//
//@WebServlet("/admin")
//public class admin extends HttpServlet {
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        PrintWriter out = response.getWriter();
//        response.setContentType("text/html");
//
//        String email = request.getParameter("email");
//        String password = request.getParameter("password");
//
//        try {
//            // Check if admin credentials are used
//            if (email.equals("admin@1234.com") && password.equals("admin123")) {
//                // Admin login: Fetch all records
//                Connection con = connection.getConnection();
//                String query = "SELECT * FROM register";
//                PreparedStatement ps = con.prepareStatement(query);
//                ResultSet rs = ps.executeQuery();
//
//                // Create a list to hold all users
//                List<User> userList = new ArrayList<>();
//
//                // Iterate through the result set and create User objects
//                while (rs.next()) {
//                    User user = new User();
//                    user.setName(rs.getString("name"));
//                    user.setEmail(rs.getString("email"));
//                    user.setMobile(rs.getString("mobile"));
//                    user.setTechnology(rs.getString("technology"));
//                    user.setCourse(rs.getString("course"));
//                    user.setOther_course(rs.getString("other_course"));
//                    user.setBranch(rs.getString("branch"));
//                    user.setGrad_completed(rs.getString("grad_completed"));
//                    user.setGrad_year(rs.getString("grad_year"));
//                    user.setCurrent_semester(rs.getString("current_semester"));
//                    user.setStart_date(rs.getString("start_date"));
//                    user.setDuration(rs.getString("duration"));
//                    user.setEnd_date(rs.getString("end_date"));
//                    user.setReference(rs.getString("reference"));
//
//                    userList.add(user);
//                }
//
//                // Closing resources
//                rs.close();
//                ps.close();
//                con.close();
//
//                // Assume you want to retrieve the first user for demonstration
//                if (!userList.isEmpty()) {
//                    User sessionUser = userList.get(0); // Retrieve the first user (you can adjust this logic)
//
//                    // Store the user object in session attribute
//                    HttpSession session = request.getSession(true); // Get or create a session
//                    session.setAttribute("session_User", sessionUser);
//
//                    // Forwarding to admin profile page
//                    RequestDispatcher rd = request.getRequestDispatcher("/admin_dashboard.jsp");
//                    rd.forward(request, response);
//                } else {
//                    // Handle case where no users found
//                    out.println("<h3 style='color:red'>No users found.</h3>");
//                    RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
//                    rd.include(request, response);
//                }
//
//            } else {
//                // Handling case where admin credentials are not correct
//                out.println("<h3 style='color:red'>Admin login failed: Incorrect credentials</h3>");
//                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
//                rd.include(request, response);
//            }
//
//        } catch (SQLException e) {
//            // Handle SQL exceptions
//            out.println("<h3 style='color:red'>Database error: " + e.getMessage() + "</h3>");
//            e.printStackTrace();
//        } catch (Exception e) {
//            // Handle other exceptions
//            out.println("<h3 style='color:red'>Error: " + e.getMessage() + "</h3>");
//            e.printStackTrace();
//        }
//    }
//}

//

package com.yash.internmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.internmanagement.domain.User;
import com.yash.internmanagement.util.connection;

@WebServlet("/admin")
public class admin extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
           
            if ("admin@1234.com".equals(email) && "admin123".equals(password)) {
           
                Connection con = connection .getConnection(); 
                String query = "SELECT * FROM register";
                PreparedStatement ps = con.prepareStatement(query);
                ResultSet rs = ps.executeQuery();

                
                List<User> userList = new ArrayList<>();

               
                while (rs.next()) {
                    User user = new User();
                    user.setId(rs.getString("id"));
                    user.setName(rs.getString("name"));
                    user.setEmail(rs.getString("email"));
                    user.setMobile(rs.getString("mobile"));
                    user.setTechnology(rs.getString("technology"));
                    user.setCourse(rs.getString("course"));
                    user.setOther_course(rs.getString("other_course"));
                    user.setBranch(rs.getString("branch"));
                    user.setGrad_completed(rs.getString("grad_completed"));
                    user.setGrad_year(rs.getString("grad_year"));
                    user.setCurrent_semester(rs.getString("current_semester"));
                    user.setStart_date(rs.getString("start_date"));
                    user.setDuration(rs.getString("duration"));
                    user.setEnd_date(rs.getString("end_date"));
                    user.setReference(rs.getString("reference"));
                    user.setStatesSelect(rs.getString("statesSelect"));
                    userList.add(user);
                }

               
                HttpSession session = request.getSession();
                session.setAttribute("userList", userList);

               
                rs.close();
                ps.close();
                con.close();

               
                RequestDispatcher rd = request.getRequestDispatcher("/admin_profile.jsp");
                rd.forward(request, response);

            } else {
                
                out.println("<h3 style='color:red'>Admin login failed: Incorrect credentials</h3>");
                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                rd.include(request, response);
            }

        } catch (SQLException e) {
         
            out.println("<h3 style='color:red'>Database error: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        } catch (Exception e) {
         
            out.println("<h3 style='color:red'>Error: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        }
    }
}

