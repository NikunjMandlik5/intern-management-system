//package com.yash.TaskManagerSystem.controller;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import com.yash.TaskManagerSystem.domain.User;
//import com.yash.TaskManagerSystem.util.connection;
//
//@WebServlet("/login")
//public class login extends HttpServlet {
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        PrintWriter out = response.getWriter();
//        response.setContentType("text/html");
//
//        String email = request.getParameter("email");
//        String password = request.getParameter("password");
//
//        try {
//        	 
//            // Existing user login check
//            Connection con = connection.getConnection();
//            String query = "SELECT * FROM register WHERE email=? AND password=?";
//            PreparedStatement ps = con.prepareStatement(query);
//            ps.setString(1, email);
//            ps.setString(2, password);
//
//            ResultSet rs = ps.executeQuery();
//            if (rs.next()) {
//                // Creating a User object and setting its attributes from database
//                User user = new User();
//                user.setName(rs.getString("name"));
//                user.setEmail(rs.getString("email"));
//                user.setMobile(rs.getString("mobile"));
//                user.setTechnology(rs.getString("technology"));
//                user.setCourse(rs.getString("course"));
//                user.setOther_course(rs.getString("other_course"));
//                user.setBranch(rs.getString("branch"));
//                user.setGrad_completed(rs.getString("grad_completed"));
//                user.setGrad_year(rs.getString("grad_year"));
//                user.setCurrent_semester(rs.getString("current_semester"));
//                user.setStart_date(rs.getString("start_date"));
//                user.setDuration(rs.getString("duration"));
//                user.setEnd_date(rs.getString("end_date"));
//                user.setReference(rs.getString("reference"));
//
//                // Storing the User object in session attribute
//                HttpSession session = request.getSession();
//                session.setAttribute("session_User", user);
//
//                // Forwarding to profile.jsp upon successful login
//                RequestDispatcher rd = request.getRequestDispatcher("/profile.jsp");
//                rd.forward(request, response);
//            } else {
//                // Handling case where login credentials do not match
//                out.println("<h3 style='color:red'>Email id and password didn't match</h3>");
//                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
//                rd.include(request, response);
//            }
//
//            // Closing resources
//            rs.close();
//            ps.close();
//            con.close();
//
//        } catch (SQLException e) {
//            // Handle SQL exceptions
//            out.println("<h3 style='color:red'>Database error: " + e.getMessage() + "</h3>");
//            e.printStackTrace();
//        } catch (Exception e) {
//            // Handle other exceptions
//            out.println("<h3 style='color:red'>Error: " + e.getMessage() + "</h3>");
//            e.printStackTrace();
//        }
//    }
//}







package com.yash.internmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.internmanagement.domain.User;
import com.yash.internmanagement.util.connection;

@WebServlet("/login")
public class login extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
        	
            Connection con = connection.getConnection();
            String query = "SELECT * FROM register WHERE email=? AND password=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                
                User user = new User();
                user.setId(rs.getString("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setMobile(rs.getString("mobile"));
                user.setTechnology(rs.getString("technology"));
                user.setCourse(rs.getString("course"));
                user.setOther_course(rs.getString("other_course"));
                user.setBranch(rs.getString("branch"));
                user.setGrad_completed(rs.getString("grad_completed"));
                user.setGrad_year(rs.getString("grad_year"));
                user.setCurrent_semester(rs.getString("current_semester"));
                user.setStart_date(rs.getString("start_date"));
                user.setDuration(rs.getString("duration"));
                user.setEnd_date(rs.getString("end_date"));
                user.setReference(rs.getString("reference"));

              
                HttpSession session = request.getSession();
                session.setAttribute("session_User", user);

                
                RequestDispatcher rd = request.getRequestDispatcher("/profile.jsp");
                rd.forward(request, response);
            } else {
                
                out.println("<h3 style='color:red'>Email id and password didn't match</h3>");
                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                rd.include(request, response);
            }

           
            rs.close();
            ps.close();
            con.close();

        } catch (SQLException e) {
           
            out.println("<h3 style='color:red'>Database error: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        } 
        catch (Exception e) {
            
            out.println("<h3 style='color:red'>Error: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        }
    }
}

