/*
 * package com.yash.TaskManagerSystem.controller;
 * 
 * import com.yash.TaskManagerSystem.util.connection;
 * 
 * import java.io.IOException; import java.io.PrintWriter; import
 * java.sql.Connection; import java.sql.PreparedStatement; import
 * java.sql.SQLException;
 * 
 * import javax.servlet.RequestDispatcher; import
 * javax.servlet.ServletException; import javax.servlet.annotation.WebServlet;
 * import javax.servlet.http.HttpServlet; import
 * javax.servlet.http.HttpServletRequest; import
 * javax.servlet.http.HttpServletResponse;
 * 
 * @WebServlet("/admin_dashboard") public class intern_states extends
 * HttpServlet { private static final long serialVersionUID = 1L;
 * 
 * public intern_states() { super(); }
 * 
 * protected void doPost(HttpServletRequest request, HttpServletResponse
 * response) throws ServletException, IOException { PrintWriter out =
 * response.getWriter(); response.setContentType("text/html");
 * 
 * // Get parameters from the request String newValue =
 * request.getParameter("newValue"); String optionValue =
 * request.getParameter("optionValue");
 * 
 * try { // Get connection from connection pool Connection con =
 * connection.getConnection();
 * 
 * // Prepare SQL statement String sql =
 * "UPDATE options_table SET option_value = ? WHERE option_name = ?";
 * PreparedStatement ps = con.prepareStatement(sql); ps.setString(1, newValue);
 * ps.setString(2, optionValue);
 * 
 * // Execute the update int count = ps.executeUpdate();
 * 
 * if (count > 0) { // Update successful, redirect to admin_dashboard.jsp
 * RequestDispatcher rd = request.getRequestDispatcher("/admin_dashboard.jsp");
 * rd.forward(request, response); } else {
 * out.println("<h3 style='color:red'>Update Failed</h3>"); RequestDispatcher rd
 * = request.getRequestDispatcher("/admin_dashboard.jsp"); rd.include(request,
 * response); }
 * 
 * ps.close(); con.close(); } catch (SQLException e) {
 * out.println("<h3 style='color:red'>An error occurred: " + e.getMessage() +
 * "</h3>"); e.printStackTrace(); } } }
 */



//
//package com.yash.TaskManagerSystem.controller;
//
//import com.yash.TaskManagerSystem.util.connection;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//@WebServlet("/admin_dashboard")
//public class intern_states extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//
//    public intern_states() {
//        super();
//    }
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        PrintWriter out = response.getWriter();
//        response.setContentType("text/html");
//
//        // Get parameters from the request
//        String newValue = request.getParameter("newValue");
//        String optionValue = request.getParameter("optionValue");
//
//        try {
//            // Get connection from connection pool
//            Connection con = connection.getConnection();
//
//            // Prepare SQL statement
//            String sql = "UPDATE options_table SET option_value = ? WHERE option_name = ?";
//            PreparedStatement ps = con.prepareStatement(sql);
//            ps.setString(1, newValue);
//            ps.setString(2, optionValue);
//
//            // Execute the update
//            int count = ps.executeUpdate();
//
//            if (count > 0) {
//                // Update successful, redirect to admin_dashboard.jsp
//                response.sendRedirect(request.getContextPath() + "/admin_dashboard.jsp");
//            } else {
//                out.println("<h3 style='color:red'>Update Failed</h3>");
//                RequestDispatcher rd = request.getRequestDispatcher("/admin_dashboard.jsp");
//                rd.include(request, response);
//            }
//
//            ps.close();
//            con.close();
//        } catch (SQLException e) {
//            // Log the exception instead of printing to response
//            e.printStackTrace();
//            out.println("<h3 style='color:red'>An error occurred while updating: " + e.getMessage() + "</h3>");
//        }
//    }
//}



//
//package com.yash.TaskManagerSystem.controller;
//
//import com.yash.TaskManagerSystem.util.connection;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//@WebServlet("/admin_dashboard")
//public class intern_states extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//
//    public intern_states() {
//        super();
//    }
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        PrintWriter out = response.getWriter();
//        response.setContentType("text/html");
//
//        // Get parameters from the request
//        String userId = request.getParameter("userId");
//        String newStatus = request.getParameter("newStatus");
//
//        try {
//            // Get connection from connection pool
//            Connection con = connection.getConnection();
//
//            // Prepare SQL statement
//            String sql = "UPDATE register SET statesSelect = ? WHERE id = ?";
//            PreparedStatement ps = con.prepareStatement(sql);
//            ps.setString(1, newStatus);
//            ps.setString(2, userId);
//
//            // Execute the update
//            int count = ps.executeUpdate();
//
//            if (count > 0) {
//                // Update successful, send success response (optional)
//            	System.out.println("Hello");
//                response.setStatus(HttpServletResponse.SC_OK);
//            } else {
//                // Update failed, send error response (optional)
//                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//                out.println("<h3 style='color:red'>Update Failed</h3>");
//            }
//
//            ps.close();
//            con.close();
//        } catch (SQLException e) {
//            // Log the exception instead of printing to response
//            e.printStackTrace();
//            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//            out.println("<h3 style='color:red'>An error occurred while updating: " + e.getMessage() + "</h3>");
//        }
//    }
//}











//
//package com.yash.TaskManagerSystem.controller;
//
//import com.yash.TaskManagerSystem.util.connection;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//@WebServlet("/admin_dashboard")
//public class intern_states extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//
//    public intern_states() {
//        super();
//    }
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        PrintWriter out = response.getWriter();
//        response.setContentType("text/html");
//
//        String id = request.getParameter("id");
//        String newStatus = request.getParameter("statesSelect");
//
//        try {
//            Connection con = connection.getConnection();
//            String insert_sql_query = "INSERT INTO register ( statesSelect = ? WHERE id = ?)";
//            PreparedStatement ps = con.prepareStatement(insert_sql_query);
//            ps.setString(1, newStatus);
//            ps.setString(2, id);
//
//            int count = ps.executeUpdate();
//            if (count > 0) {
//                // Update successful, redirect to admin_dashboard.jsp
//                response.sendRedirect("admin_dashboard.jsp");
//            } else {
//                out.println("<h3 style='color:red'>Update Failed</h3>");
//                RequestDispatcher rd = request.getRequestDispatcher("/admin_dashboard.jsp");
//                rd.include(request, response);
//            }
//
//            ps.close();
//            con.close();
//        } catch (SQLException e) {
//            out.println("<h3 style='color:red'>An error occurred: " + e.getMessage() + "</h3>");
//            e.printStackTrace();
//        }
//    }
//}



package com.yash.internmanagement.controller;

import com.yash.internmanagement.util.connection;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/useredit")
public class useredit extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public useredit() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String id = request.getParameter("id");
        out.println(id);

        Connection con = null;
        PreparedStatement ps = null;

        try {
            con = connection.getConnection();

           
            String updateSql = "UPDATE register SET edit_request = 'yes' WHERE id = ?";
            ps = con.prepareStatement(updateSql);

           
            ps.setString(1, id);

            int count = ps.executeUpdate();
            if (count > 0) {
                
                response.sendRedirect("useredit.jsp");
            } else {
                out.println("<h3 style='color:red'>Update Failed</h3>");
                request.getRequestDispatcher("/profile.jsp").include(request, response);
            }
        } catch (SQLException e) {
            out.println("<h3 style='color:red'>An error occurred: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
