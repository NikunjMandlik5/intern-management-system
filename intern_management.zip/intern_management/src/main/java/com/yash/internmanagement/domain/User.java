package com.yash.internmanagement.domain;

public class User {
    private String id;
    private String name;
    private String email;
    private String mobile;
    private String technology;
    private String course;
    private String other_course;
    private String branch;
    private String grad_completed;
    private String grad_year;
    private String current_semester;
    private String start_date;
    private String duration;
    private String end_date;
    private String reference;
    private String statesSelect;  
    private String request;  
    private String edit_request;  
    
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getOther_course() {
        return other_course;
    }

    public void setOther_course(String other_course) {
        this.other_course = other_course;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getGrad_completed() {
        return grad_completed;
    }

    public void setGrad_completed(String grad_completed) {
        this.grad_completed = grad_completed;
    }

    public String getGrad_year() {
        return grad_year;
    }

    public void setGrad_year(String grad_year) {
        this.grad_year = grad_year;
    }

    public String getCurrent_semester() {
        return current_semester;
    }

    public void setCurrent_semester(String current_semester) {
        this.current_semester = current_semester;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getStatesSelect() {
        return statesSelect;
    }

    public void setStatesSelect(String statesSelect) {
        this.statesSelect = statesSelect;
    }
    
    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }
    
    public String getEdit_request() {
        return edit_request;
    }

    public void setEdit_request(String edit_request) {
        this.edit_request = edit_request;
    }
}

