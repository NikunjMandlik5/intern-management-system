////package com.yash.TaskManagerSystem.util;
////
////import java.sql.Connection;
////import java.sql.DriverManager;
////import java.sql.SQLException;
////
////public class connection {
////
////   private static final String url = "jdbc:mysql://localhost:3306/intern"; // Update database name here
////	    private static final String username = "root";
////	    private static final String password = "root";
////
////	    public static Connection getConnection() throws SQLException {
////	        Connection con = null;
////	        try {
////	            Class.forName("com.mysql.cj.jdbc.Driver");
////	            con = DriverManager.getConnection(url, username, password);
////	        } catch (ClassNotFoundException | SQLException e) {
////	            e.printStackTrace();
////	            throw new SQLException("Error in database connection: " + e.getMessage());
////	        }
////	        return con;
////	    }
////	}
//
//
//
//package com.yash.TaskManagerSystem.util;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//
//public class connection {
//
//    private static final String URL = "jdbc:mysql://localhost:3306/intern"; // Update database name here
//    private static final String USERNAME = "root";
//    private static final String PASSWORD = "root";
//
//    static {
//        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//            throw new IllegalStateException("Failed to load JDBC driver: " + e.getMessage());
//        }
//    }
//
//    public static Connection getConnection() throws SQLException {
//        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
//        return connection;
//    }
//}



package com.yash.internmanagement.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connection {

    private static final String URL = "jdbc:mysql://localhost:3306/intern";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new IllegalStateException("Failed to load JDBC driver: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}

